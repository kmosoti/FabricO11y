"""Exploratory: attribute query time on one 40 MB state: unsealed tail vs sealed Segment.
Usage: qattr.py <state-src> <out-root>
"""
import http.client, json, os, shutil, signal, ssl, subprocess, sys, time, statistics, urllib.request
from pathlib import Path
import research_paths
from delivery_faults import free_port, make_certs

BINS = research_paths.REPO / "target" / "release"
SRC, ROOT = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
shutil.rmtree(ROOT, ignore_errors=True); ROOT.mkdir(parents=True)
make_certs(ROOT)
TOKEN = "ab" * 32
(ROOT / "admin-token").write_text(TOKEN + "\n")
kids = []

def pct(v, p):
    v = sorted(v); k = (len(v) - 1) * p / 100; f = int(k); c = min(f + 1, len(v) - 1)
    return v[f] + (v[c] - v[f]) * (k - f)

class Q:
    def __init__(self, port):
        self.port = port; self.ctx = ssl.create_default_context(cafile=str(ROOT / "ca.pem")); self.conn = None
    def post(self, body):
        if self.conn is None:
            self.conn = http.client.HTTPSConnection("127.0.0.1", self.port, context=self.ctx, timeout=120)
        self.conn.request("POST", "/v1/admin/query", body=json.dumps(body).encode(),
                          headers={"authorization": f"Bearer {TOKEN}", "content-type": "application/json"})
        r = self.conn.getresponse(); data = r.read()
        return r.status, json.loads(data)

def start(name, file_bytes):
    state = ROOT / f"{name}-state"; shutil.copytree(SRC, state)
    # the source state's admin token differs; the control dir is separate from the journal, so replace it
    port = free_port()
    conf = ROOT / f"{name}.conf"
    conf.write_text(f"listen=127.0.0.1:{port}\ntls_cert={ROOT}/server.pem\ntls_key={ROOT}/server.key\n"
                    f"state_dir={state}\nadmin_token_file={ROOT}/admin-token\njournal_bytes=4294967296\njournal_file_bytes={file_bytes}\n")
    p = subprocess.Popen(["taskset", "-c", "0-1", str(BINS / "fabric-server"), "serve", str(conf)],
                         stdout=open(ROOT / f"{name}.log", "wb"), stderr=subprocess.STDOUT)
    kids.append(p)
    q = Q(port); t0 = time.monotonic(); deadline = t0 + 600
    while True:
        try:
            q.post({"kind": "logs", "from_ns": 0, "to_ns": 1, "limit": 1, "page": None}); break
        except Exception:
            q.conn = None
            if time.monotonic() > deadline or p.poll() is not None: raise SystemExit(f"{name} did not start")
            time.sleep(0.2)
    ready_s = round(time.monotonic() - t0, 1); print(f"  {name}: ready after {ready_s} s (journal replay)", flush=True)
    result.setdefault("ready_s", {})[name] = ready_s
    return p, q, port, state, conf

def window(q):
    st, ans = q.post({"kind": "logs", "from_ns": 0, "to_ns": 2**63, "limit": 1, "page": None})
    return max(0, ans["retained_from_ns"] - 60_000_000_000), ans["retained_to_ns"]

def queries(a, b):
    return [
        ("empty_window_past",  {"kind": "logs", "from_ns": 1, "to_ns": 2, "limit": 100, "page": None}),
        ("host_logs_1000",     {"kind": "logs", "node": "sim0007", "from_ns": a, "to_ns": b + 1, "limit": 1000, "page": None}),
        ("logs_limit_50",      {"kind": "logs", "from_ns": a, "to_ns": b + 1, "limit": 50, "page": None}),
        ("text_rare",          {"kind": "logs", "from_ns": a, "to_ns": b + 1, "contains": "zq9", "limit": 100, "page": None}),
        ("text_common",        {"kind": "logs", "from_ns": a, "to_ns": b + 1, "contains": "RRRRRRRR", "limit": 100, "page": None}),
        ("metric_history_1000",{"kind": "metrics", "node": "sim0003", "name": "sim.metric.7", "from_ns": a, "to_ns": b + 1, "limit": 1000, "page": None}),
        ("fleet_metrics_10000",{"kind": "metrics", "name": "sim.metric.3", "from_ns": a, "to_ns": b + 1, "limit": 10000, "page": None}),
        ("rate",               {"kind": "rate", "name": "sim.metric.0", "from_ns": a, "to_ns": b + 1}),
    ]

def bench(q, a, b, reps=12):
    out = {}
    for name, body in queries(a, b):
        ts, rows, complete = [], None, None
        for _ in range(reps):
            t = time.perf_counter(); st, ans = q.post(body); ts.append((time.perf_counter() - t) * 1000)
            assert st == 200, (name, st, ans)
            rows = len(ans.get("rows", [])); complete = ans.get("complete")
        out[name] = {"p50_ms": round(pct(ts, 50), 1), "min_ms": round(min(ts), 1), "max_ms": round(max(ts), 1), "rows": rows, "complete": complete}
        print(f"  {name:22} p50 {out[name]['p50_ms']:8.1f}  min {out[name]['min_ms']:8.1f}  rows {rows}", flush=True)
    return out

def fabricctl(port, body, reps=5):
    conf = ROOT / "admin.conf"
    conf.write_text(f"server_url=https://127.0.0.1:{port}\nserver_ca={ROOT}/ca.pem\nadmin_token_file={ROOT}/admin-token\n")
    ts = []
    for _ in range(reps):
        t = time.perf_counter()
        r = subprocess.run([str(BINS / "fabricctl"), "admin", str(conf), "query", json.dumps(body)], capture_output=True, text=True, timeout=120)
        ts.append((time.perf_counter() - t) * 1000)
        assert r.returncode == 0, r.stderr[:200]
    return round(pct(ts, 50), 1)

def state_sizes(state):
    j = sum(f.stat().st_size for f in (state / "journal").glob("*.faj"))
    s = sum(f.stat().st_size for f in (state / "segments").rglob("*") if f.is_file()) if (state / "segments").exists() else 0
    return {"journal_bytes": j, "segment_bytes": s, "segments": len(list((state / "segments").glob("seg-*"))) if (state / "segments").exists() else 0}

result = {}
try:
    pass
except Exception: pass
try:
    print("== A: whole state as unsealed journal tail")
    pa, qa, porta, statea, _ = start("tail", 64 * 1024 * 1024)
    a, b = window(qa)
    result["A_tail"] = {"sizes": state_sizes(statea), "queries": bench(qa, a, b)}
    result["A_tail"]["fabricctl_host_logs_p50_ms"] = fabricctl(porta, queries(a, b)[1][1])
    result["A_tail"]["fabricctl_empty_p50_ms"] = fabricctl(porta, queries(a, b)[0][1])
    print("  fabricctl host_logs p50", result["A_tail"]["fabricctl_host_logs_p50_ms"], "empty", result["A_tail"]["fabricctl_empty_p50_ms"])
    pa.send_signal(signal.SIGTERM); pa.wait(timeout=60)

    print("== B: same state, journal rotated and sealed into a Segment")
    pb, qb, portb, stateb, confb = start("sealed", 65536)
    # one appended Batch triggers rotation of the 40 MB active file; the sealer then builds the Segment
    req = urllib.request.Request(f"https://127.0.0.1:{portb}/v1/admin/nodes", data=json.dumps({"name": "kicker", "metric_interval_s": 15}).encode(),
                                 method="POST", headers={"authorization": f"Bearer {TOKEN}", "content-type": "application/json"})
    with urllib.request.urlopen(req, context=qb.ctx, timeout=30) as r: tok = json.loads(r.read())["token"]
    (ROOT / "kick-tokens").write_text(tok + "\n")
    subprocess.run([str(BINS / "examples" / "spindle_sim"), "--server-url", f"https://127.0.0.1:{portb}", "--ca", str(ROOT / "ca.pem"),
                    "--tokens", str(ROOT / "kick-tokens"), "--seed", "0xA11FA001", "--seconds", "2", "--workers", "1", "--out", str(ROOT / "kick")],
                   capture_output=True, timeout=120)
    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if list((stateb / "segments").glob("seg-*")) and not list((stateb / "journal").glob("sealed-*")): break
        time.sleep(0.5)
    sz = state_sizes(stateb); print("  sizes", sz)
    result["B_sealed"] = {"sizes": sz, "queries": bench(qb, a, b)}
    result["B_sealed"]["fabricctl_host_logs_p50_ms"] = fabricctl(portb, queries(a, b)[1][1])
    result["B_sealed"]["fabricctl_empty_p50_ms"] = fabricctl(portb, queries(a, b)[0][1])
    print("  fabricctl host_logs p50", result["B_sealed"]["fabricctl_host_logs_p50_ms"], "empty", result["B_sealed"]["fabricctl_empty_p50_ms"])
    pb.send_signal(signal.SIGTERM); pb.wait(timeout=60)
    result["segment_dir"] = str(next((stateb / "segments").glob("seg-*")))
    json.dump(result, open(ROOT / "qattr.json", "w"), indent=1)
finally:
    for p in kids:
        if p.poll() is None: p.kill(); p.wait(timeout=10)
