//! Immutable JSON snapshot publication and restartable query progress.
use std::{
    fs::{self, File, OpenOptions},
    io::{self, Read, Write},
    num::NonZeroUsize,
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
};

use fabric_o11y::{
    Attribute, Event, EventId, EventTime, ObservedTime, Payload, ResourceId, Scalar, SourceId,
    TenantId,
};
use serde::{Deserialize, Serialize};
use sha2::{Digest as _, Sha256};

use crate::{
    Query,
    coverage::{
        self, Anchor, BlockCommitment, BlockReceipt, Digest, Disposition, Receipt, Summary,
    },
    resume::{self, Accumulator, Binding, MatchedRow, Page, Residual},
};

const MAX_FILE: usize = 64 * 1024 * 1024;
const CODEC_VERSION: u32 = 1;
static NEXT_STAGE: AtomicU64 = AtomicU64::new(0);

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
pub struct Publication {
    pub anchor: Anchor,
    pub block_rows: usize,
    pub codec_version: u32,
}
#[derive(Clone, Debug, Default, Eq, PartialEq)]
pub struct ReadMetrics {
    pub metadata_bytes: u64,
    pub raw_bytes: u64,
    pub raw_files: usize,
    pub unavailable: Vec<usize>,
}
pub struct DiskAnswer {
    pub page: Page,
    pub reads: ReadMetrics,
}
pub struct DiskSnapshot {
    dir: PathBuf,
    expected: Publication,
    blocks: Vec<MetaBlock>,
    metadata_bytes: u64,
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EventEnvelope {
    version: u32,
    events: Vec<EventWire>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct EventWire {
    id: u64,
    tenant: u64,
    source: u64,
    resource: u64,
    event_time: i64,
    observed_time: i64,
    attributes: Vec<AttributeWire>,
    payload: PayloadWire,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct AttributeWire {
    key: String,
    value: ScalarWire,
}
#[derive(Serialize, Deserialize)]
#[serde(tag = "kind", content = "value", deny_unknown_fields)]
enum ScalarWire {
    #[serde(rename = "bool")]
    Bool(bool),
    #[serde(rename = "i64")]
    I64(i64),
    #[serde(rename = "u64")]
    U64(u64),
    #[serde(rename = "string")]
    String(String),
    #[serde(rename = "f64_bits")]
    F64Bits(String),
}
#[derive(Serialize, Deserialize)]
#[serde(tag = "kind", deny_unknown_fields)]
enum PayloadWire {
    #[serde(rename = "log")]
    Log { body: String },
    #[serde(rename = "gauge")]
    Gauge {
        name: String,
        value_bits: String,
        unit: String,
    },
}

#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Manifest {
    version: u32,
    block_rows: usize,
    anchor: Anchor,
    blocks: Vec<MetaBlock>,
}
#[derive(Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct MetaBlock {
    commitment: BlockCommitment,
    summary: Summary,
    proof: Vec<Digest>,
}
#[derive(Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct Checkpoint {
    version: u32,
    binding: Binding,
    pages: Vec<Page>,
}

fn invalid(message: &str) -> io::Error {
    io::Error::new(io::ErrorKind::InvalidData, message)
}
fn json<T: Serialize>(value: &T) -> io::Result<Vec<u8>> {
    let bytes = serde_json::to_vec(value).map_err(|e| invalid(&e.to_string()))?;
    if bytes.len() > MAX_FILE {
        return Err(invalid("JSON file exceeds 64 MiB"));
    }
    Ok(bytes)
}
fn parse<T: for<'de> Deserialize<'de>>(bytes: &[u8]) -> io::Result<T> {
    if bytes.len() > MAX_FILE {
        return Err(invalid("JSON file exceeds 64 MiB"));
    }
    serde_json::from_slice(bytes).map_err(|e| invalid(&e.to_string()))
}
fn float_hex(bits: u64) -> String {
    format!("{bits:016x}")
}
fn parse_float_hex(s: &str) -> io::Result<u64> {
    if s.len() != 16
        || !s
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return Err(invalid("invalid lowercase float bits"));
    }
    u64::from_str_radix(s, 16).map_err(|e| invalid(&e.to_string()))
}
fn event_to_wire(e: &Event) -> EventWire {
    EventWire {
        id: e.id.0,
        tenant: e.tenant.0,
        source: e.source.0,
        resource: e.resource.0,
        event_time: e.event_time.0,
        observed_time: e.observed_time.0,
        attributes: e
            .attributes
            .iter()
            .map(|a| AttributeWire {
                key: a.key.clone(),
                value: match &a.value {
                    Scalar::Bool(v) => ScalarWire::Bool(*v),
                    Scalar::I64(v) => ScalarWire::I64(*v),
                    Scalar::U64(v) => ScalarWire::U64(*v),
                    Scalar::String(v) => ScalarWire::String(v.clone()),
                    Scalar::F64(v) => ScalarWire::F64Bits(float_hex(v.to_bits())),
                },
            })
            .collect(),
        payload: match &e.payload {
            Payload::Log { body } => PayloadWire::Log { body: body.clone() },
            Payload::Gauge { name, value, unit } => PayloadWire::Gauge {
                name: name.clone(),
                value_bits: float_hex(value.to_bits()),
                unit: unit.clone(),
            },
        },
    }
}
fn wire_to_event(e: EventWire) -> io::Result<Event> {
    let attributes = e
        .attributes
        .into_iter()
        .map(|a| {
            Ok(Attribute {
                key: a.key,
                value: match a.value {
                    ScalarWire::Bool(v) => Scalar::Bool(v),
                    ScalarWire::I64(v) => Scalar::I64(v),
                    ScalarWire::U64(v) => Scalar::U64(v),
                    ScalarWire::String(v) => Scalar::String(v),
                    ScalarWire::F64Bits(v) => Scalar::F64(f64::from_bits(parse_float_hex(&v)?)),
                },
            })
        })
        .collect::<io::Result<Vec<_>>>()?;
    let payload = match e.payload {
        PayloadWire::Log { body } => Payload::Log { body },
        PayloadWire::Gauge {
            name,
            value_bits,
            unit,
        } => Payload::Gauge {
            name,
            value: f64::from_bits(parse_float_hex(&value_bits)?),
            unit,
        },
    };
    Ok(Event {
        id: EventId(e.id),
        tenant: TenantId(e.tenant),
        source: SourceId(e.source),
        resource: ResourceId(e.resource),
        event_time: EventTime(e.event_time),
        observed_time: ObservedTime(e.observed_time),
        attributes,
        payload,
    })
}
pub fn encode_events(events: &[Event]) -> io::Result<Vec<u8>> {
    json(&EventEnvelope {
        version: 1,
        events: events.iter().map(event_to_wire).collect(),
    })
}
pub fn decode_events(bytes: &[u8]) -> io::Result<Vec<Event>> {
    let envelope: EventEnvelope = parse(bytes)?;
    if envelope.version != 1 {
        return Err(invalid("unsupported event codec version"));
    }
    envelope.events.into_iter().map(wire_to_event).collect()
}

fn metadata_for(
    events: &[Event],
    rows: usize,
    snapshot_id: u64,
) -> io::Result<(Anchor, Vec<MetaBlock>)> {
    let mut commitments = Vec::new();
    let mut summaries = Vec::new();
    for (ordinal, block) in events.chunks(rows).enumerate() {
        let summary =
            coverage::summarize(block).map_err(|e| invalid(&format!("summary: {e:?}")))?;
        commitments.push(BlockCommitment {
            ordinal,
            start: ordinal
                .checked_mul(rows)
                .ok_or_else(|| invalid("layout overflow"))?,
            len: block.len(),
            rows_digest: coverage::rows_digest(block),
            summary_digest: coverage::summary_digest(&summary),
        });
        summaries.push(summary);
    }
    let (anchor, proofs) = coverage::authenticate(snapshot_id, events.len(), &commitments);
    let blocks = commitments
        .into_iter()
        .zip(summaries)
        .zip(proofs)
        .map(|((commitment, summary), proof)| MetaBlock {
            commitment,
            summary,
            proof,
        })
        .collect();
    Ok((anchor, blocks))
}
fn validate_manifest(m: &Manifest, expected: &Publication) -> io::Result<()> {
    if m.version != 1
        || m.block_rows == 0
        || m.block_rows != expected.block_rows
        || m.anchor != expected.anchor
        || expected.codec_version != CODEC_VERSION
    {
        return Err(invalid("manifest publication mismatch"));
    }
    if m.blocks.len() != expected.anchor.block_count {
        return Err(invalid("manifest block count mismatch"));
    }
    let mut next = 0usize;
    let mut receipts = Vec::with_capacity(m.blocks.len());
    for (i, b) in m.blocks.iter().enumerate() {
        let c = &b.commitment;
        let expected_len = expected
            .anchor
            .row_count
            .saturating_sub(i.saturating_mul(m.block_rows))
            .min(m.block_rows);
        if c.ordinal != i
            || c.start != next
            || c.len != expected_len
            || c.summary_digest != coverage::summary_digest(&b.summary)
            || b.summary.min_time > b.summary.max_time
        {
            return Err(invalid("invalid manifest block metadata"));
        }
        next = next
            .checked_add(c.len)
            .ok_or_else(|| invalid("layout overflow"))?;
        receipts.push(BlockReceipt {
            commitment: c.clone(),
            proof: b.proof.clone(),
            disposition: Disposition::Scanned,
        });
    }
    if next != expected.anchor.row_count {
        return Err(invalid("manifest row count mismatch"));
    }
    let query = Query {
        start_ns: i64::MIN,
        end_ns: i64::MAX,
        tenant: None,
        token: None,
    };
    coverage::verify(
        &expected.anchor,
        &query,
        &Receipt {
            snapshot_id: expected.anchor.snapshot_id,
            query: query.clone(),
            blocks: receipts,
        },
    )
    .map_err(|e| invalid(&format!("manifest anchor verification: {e:?}")))?;
    Ok(())
}
fn write_new_file(path: &Path, bytes: &[u8]) -> io::Result<()> {
    let mut f = OpenOptions::new().write(true).create_new(true).open(path)?;
    f.write_all(bytes)?;
    f.sync_all()?;
    Ok(())
}
fn sync_parent(path: &Path) -> io::Result<()> {
    let parent = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    File::open(parent)?.sync_all()
}
struct PublishLock(PathBuf);
impl Drop for PublishLock {
    fn drop(&mut self) {
        let _ = fs::remove_file(&self.0);
    }
}
fn publication_bytes(p: &Publication) -> io::Result<Vec<u8>> {
    json(p)
}
pub fn publish(
    events: Vec<Event>,
    block_rows: NonZeroUsize,
    snapshot_id: u64,
    final_dir: &Path,
) -> io::Result<Publication> {
    let parent = final_dir
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or(Path::new("."));
    if !parent.is_dir() {
        return Err(io::Error::new(
            io::ErrorKind::NotFound,
            "snapshot parent must exist",
        ));
    }
    let name = final_dir
        .file_name()
        .ok_or_else(|| invalid("final directory needs a name"))?;
    let mut lock_name = name.to_os_string();
    lock_name.push(".publish.lock");
    let lock_path = parent.join(lock_name);
    let _lock = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(&lock_path)?;
    let _guard = PublishLock(lock_path);
    if final_dir.exists() {
        return Err(io::Error::new(
            io::ErrorKind::AlreadyExists,
            "snapshot already exists",
        ));
    }
    let block_data = events
        .chunks(block_rows.get())
        .map(encode_events)
        .collect::<io::Result<Vec<_>>>()?;
    let (anchor, blocks_meta) = metadata_for(&events, block_rows.get(), snapshot_id)?;
    let pubn = Publication {
        anchor: anchor.clone(),
        block_rows: block_rows.get(),
        codec_version: 1,
    };
    let mut stage_name = name.to_os_string();
    stage_name.push(format!(
        ".stage.{}.{}",
        std::process::id(),
        NEXT_STAGE.fetch_add(1, Ordering::Relaxed)
    ));
    let stage = parent.join(stage_name);
    fs::create_dir(&stage)?;
    for (index, bytes) in block_data.iter().enumerate() {
        write_new_file(&stage.join(format!("block-{index}.json")), bytes)?;
    }
    let manifest = Manifest {
        version: 1,
        block_rows: block_rows.get(),
        anchor,
        blocks: blocks_meta,
    };
    write_new_file(&stage.join("manifest.json"), &json(&manifest)?)?;
    File::open(&stage)?.sync_all()?;
    fs::rename(&stage, final_dir)?;
    sync_parent(final_dir)?;
    let _ = publication_bytes(&pubn)?;
    Ok(pubn)
}

pub fn save_publication(path: &Path, p: &Publication) -> io::Result<()> {
    if p.codec_version != 1
        || p.block_rows == 0
        || p.anchor.block_count != p.anchor.row_count.div_ceil(p.block_rows)
    {
        return Err(invalid("invalid publication"));
    }
    let bytes = publication_bytes(p)?;
    write_new_file(path, &bytes)?;
    sync_parent(path)
}
pub fn load_publication(path: &Path) -> io::Result<Publication> {
    let bytes = read_bounded(path)?;
    let p: Publication = parse(&bytes)?;
    if p.codec_version != 1
        || p.block_rows == 0
        || p.anchor.block_count != p.anchor.row_count.div_ceil(p.block_rows)
    {
        return Err(invalid("invalid trusted publication"));
    }
    Ok(p)
}
fn read_bounded(path: &Path) -> io::Result<Vec<u8>> {
    read_bounded_counted(path, &mut 0)
}
fn read_bounded_counted(path: &Path, bytes_read: &mut u64) -> io::Result<Vec<u8>> {
    let f = File::open(path)?;
    let len = f.metadata()?.len();
    if len > MAX_FILE as u64 {
        return Err(invalid("file exceeds 64 MiB"));
    }
    let mut b = Vec::with_capacity(len as usize);
    let result = f.take((MAX_FILE + 1) as u64).read_to_end(&mut b);
    // A later read error does not erase bytes already returned by the filesystem.
    *bytes_read = bytes_read.saturating_add(b.len() as u64);
    result?;
    if b.len() > MAX_FILE {
        return Err(invalid("file exceeds 64 MiB"));
    }
    Ok(b)
}
impl DiskSnapshot {
    pub fn open(dir: &Path, expected: Publication) -> io::Result<Self> {
        if expected.codec_version != 1
            || expected.block_rows == 0
            || expected.anchor.block_count
                != expected.anchor.row_count.div_ceil(expected.block_rows)
        {
            return Err(invalid("invalid expected publication"));
        }
        let mut bytes_count = 0u64;
        let mut selected = None;
        let mut last = None;
        for name in ["manifest.json", "manifest.rebuilt.json"] {
            let path = dir.join(name);
            match read_bounded_counted(&path, &mut bytes_count) {
                Ok(bytes) => {
                    match parse::<Manifest>(&bytes).and_then(|m| {
                        validate_manifest(&m, &expected)?;
                        Ok(m)
                    }) {
                        Ok(m) => {
                            selected = Some(m);
                            break;
                        }
                        Err(e) => last = Some(e),
                    }
                }
                Err(e) => last = Some(e),
            }
        }
        let m = selected.ok_or_else(|| {
            last.unwrap_or_else(|| io::Error::new(io::ErrorKind::NotFound, "manifest missing"))
        })?;
        Ok(Self {
            dir: dir.to_path_buf(),
            expected,
            blocks: m.blocks,
            metadata_bytes: bytes_count,
        })
    }
    pub fn query(&self, binding: &Binding, available: &[bool]) -> io::Result<DiskAnswer> {
        check_binding(&self.expected, binding)?;
        if available.len() != self.blocks.len() {
            return Err(invalid("availability length mismatch"));
        }
        let mut reads = ReadMetrics {
            metadata_bytes: self.metadata_bytes,
            ..ReadMetrics::default()
        };
        let mut blocks = Vec::with_capacity(self.blocks.len());
        let mut rows = Vec::new();
        for (i, meta) in self.blocks.iter().enumerate() {
            let c = &meta.commitment;
            if excludes(&meta.summary, &binding.query) {
                blocks.push(BlockReceipt {
                    commitment: c.clone(),
                    proof: meta.proof.clone(),
                    disposition: Disposition::Excluded(meta.summary.clone()),
                });
                continue;
            }
            if !available[i] {
                reads.unavailable.push(i);
                blocks.push(BlockReceipt {
                    commitment: c.clone(),
                    proof: meta.proof.clone(),
                    disposition: Disposition::Unavailable,
                });
                continue;
            }
            match self.read_block(i, c, &mut reads) {
                Some(events) => {
                    for (offset, event) in events.iter().enumerate() {
                        if matches_query(event, &binding.query) {
                            rows.push(MatchedRow {
                                block: i,
                                offset,
                                digest: coverage::rows_digest(std::slice::from_ref(event)),
                            });
                        }
                    }
                    blocks.push(BlockReceipt {
                        commitment: c.clone(),
                        proof: meta.proof.clone(),
                        disposition: Disposition::Scanned,
                    });
                }
                None => {
                    reads.unavailable.push(i);
                    blocks.push(BlockReceipt {
                        commitment: c.clone(),
                        proof: meta.proof.clone(),
                        disposition: Disposition::Unavailable,
                    });
                }
            }
        }
        let receipt = Receipt {
            snapshot_id: binding.anchor.snapshot_id,
            query: binding.query.clone(),
            blocks,
        };
        Ok(DiskAnswer {
            page: Page {
                binding: binding.clone(),
                receipt,
                rows,
            },
            reads,
        })
    }
    pub fn resume(&self, residual: &Residual, available: &[bool]) -> io::Result<DiskAnswer> {
        check_binding(&self.expected, &residual.binding)?;
        if available.len() != self.blocks.len() {
            return Err(invalid("availability length mismatch"));
        }
        let mut permitted = vec![false; self.blocks.len()];
        let mut prior = None;
        for c in &residual.blocks {
            let i = c.ordinal;
            if i >= self.blocks.len()
                || prior.is_some_and(|p| i <= p)
                || self.blocks[i].commitment != *c
            {
                return Err(invalid("invalid residual"));
            }
            permitted[i] = available[i];
            prior = Some(i);
        }
        self.query(&residual.binding, &permitted)
    }
    fn read_block(
        &self,
        index: usize,
        c: &BlockCommitment,
        metrics: &mut ReadMetrics,
    ) -> Option<Vec<Event>> {
        for path in [
            self.dir.join(format!("block-{index}.json")),
            self.dir.join("cold").join(format!("block-{index}.json")),
        ] {
            metrics.raw_files += 1;
            match read_bounded_counted(&path, &mut metrics.raw_bytes) {
                Ok(bytes) => {
                    if let Ok(rows) = decode_events(&bytes) {
                        if rows.len() == c.len && coverage::rows_digest(&rows) == c.rows_digest {
                            return Some(rows);
                        }
                    }
                }
                Err(_) => {}
            }
        }
        None
    }
}
fn check_binding(expected: &Publication, b: &Binding) -> io::Result<()> {
    if b.anchor != expected.anchor
        || b.tokenizer_version != resume::TOKENIZER_VERSION
        || b.order_version != resume::ORDER_VERSION
    {
        return Err(invalid("unsupported or mismatched binding"));
    }
    Ok(())
}
fn excludes(s: &Summary, q: &Query) -> bool {
    q.start_ns > q.end_ns
        || s.max_time < q.start_ns
        || s.min_time > q.end_ns
        || q.tenant.is_some_and(|t| !s.tenants.contains(&t))
        || q.token.as_ref().is_some_and(|t| !s.tokens.contains(t))
}
fn matches_query(e: &Event, q: &Query) -> bool {
    q.start_ns <= e.event_time.0
        && e.event_time.0 <= q.end_ns
        && q.tenant.is_none_or(|t| t == e.tenant.0)
        && match (&q.token, &e.payload) {
            (None, _) => true,
            (Some(t), Payload::Log { body }) => body.split_whitespace().any(|x| x == t),
            (Some(_), Payload::Gauge { .. }) => false,
        }
}

pub fn rebuild_manifest(dir: &Path, expected: &Publication) -> io::Result<PathBuf> {
    if expected.codec_version != 1 || expected.block_rows == 0 {
        return Err(invalid("invalid expected publication"));
    }
    let path = dir.join("manifest.rebuilt.json");
    if path.exists() {
        return Err(io::Error::new(
            io::ErrorKind::AlreadyExists,
            "rebuilt manifest already exists",
        ));
    }
    let count = expected.anchor.row_count.div_ceil(expected.block_rows);
    if count != expected.anchor.block_count {
        return Err(invalid("expected layout invalid"));
    }
    let mut events = Vec::with_capacity(expected.anchor.row_count);
    for i in 0..count {
        let candidates = [
            dir.join(format!("block-{i}.json")),
            dir.join("cold").join(format!("block-{i}.json")),
        ];
        let mut found = None;
        for c in candidates {
            if let Ok(bytes) = read_bounded(&c) {
                if let Ok(r) = decode_events(&bytes) {
                    let need = (expected.anchor.row_count - i * expected.block_rows)
                        .min(expected.block_rows);
                    if r.len() == need {
                        found = Some(r);
                        break;
                    }
                }
            }
        }
        events.extend(found.ok_or_else(|| invalid("required rebuild block unavailable"))?);
    }
    let (rebuilt_anchor, blocks) =
        metadata_for(&events, expected.block_rows, expected.anchor.snapshot_id)?;
    if rebuilt_anchor != expected.anchor {
        return Err(invalid("rebuilt rows do not match independent anchor"));
    }
    let manifest = Manifest {
        version: 1,
        block_rows: expected.block_rows,
        anchor: expected.anchor.clone(),
        blocks,
    };
    write_new_file(&path, &json(&manifest)?)?;
    sync_parent(&path)?;
    Ok(path)
}

pub fn save_checkpoint(path: &Path, binding: &Binding, pages: &[Page]) -> io::Result<Digest> {
    if pages.is_empty() {
        return Err(invalid("empty checkpoint history"));
    }
    if pages[0].binding != *binding {
        return Err(invalid("checkpoint binding mismatch"));
    }
    let mut acc = Accumulator::new(binding.clone(), pages[0].clone())
        .map_err(|e| invalid(&format!("page validation: {e:?}")))?;
    for p in &pages[1..] {
        acc.merge(p.clone())
            .map_err(|e| invalid(&format!("page merge: {e:?}")))?;
    }
    let bytes = json(&Checkpoint {
        version: 1,
        binding: binding.clone(),
        pages: pages.to_vec(),
    })?;
    write_new_file(path, &bytes)?;
    sync_parent(path)?;
    Ok(Sha256::digest(&bytes).into())
}
pub fn load_checkpoint(
    path: &Path,
    expected_binding: &Binding,
    expected_digest: Digest,
) -> io::Result<(Accumulator, Vec<Page>)> {
    let bytes = read_bounded(path)?;
    let digest: Digest = Sha256::digest(&bytes).into();
    if digest != expected_digest {
        return Err(invalid("checkpoint digest mismatch"));
    }
    let checkpoint: Checkpoint = parse(&bytes)?;
    if checkpoint.version != 1
        || checkpoint.binding != *expected_binding
        || checkpoint.pages.is_empty()
    {
        return Err(invalid("checkpoint binding or version mismatch"));
    }
    let first = checkpoint.pages[0].clone();
    let mut acc = Accumulator::new(expected_binding.clone(), first)
        .map_err(|e| invalid(&format!("page validation: {e:?}")))?;
    for p in &checkpoint.pages[1..] {
        acc.merge(p.clone())
            .map_err(|e| invalid(&format!("page merge: {e:?}")))?;
    }
    Ok((acc, checkpoint.pages))
}
