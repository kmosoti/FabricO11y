//! Retained history end to end: sealing into segments, queries graded by the
//! independent Python oracle, crash recovery of sealing, retention, stream
//! checkpoints and incomplete answers.

use fabric_o11y::spindle::sender::{Delivery, Sender, ServerTarget, agent};
use fabric_o11y::spindle::spool::{Batch, Spool};
use fabric_server::config::Config;
use fabric_server::control::{Control, DesiredConfig};
use fabric_server::query::{History, Plan, Query};
use fabric_server::store::{CommitMode, Store};
use opentelemetry_proto::tonic::collector::logs::v1::ExportLogsServiceRequest;
use opentelemetry_proto::tonic::collector::metrics::v1::ExportMetricsServiceRequest;
use opentelemetry_proto::tonic::collector::trace::v1::ExportTraceServiceRequest;
use opentelemetry_proto::tonic::common::v1::{AnyValue, KeyValue, any_value};
use opentelemetry_proto::tonic::logs::v1::{LogRecord, ResourceLogs, ScopeLogs};
use opentelemetry_proto::tonic::metrics::v1::{
    Metric, NumberDataPoint, ResourceMetrics, ScopeMetrics, Sum, metric, number_data_point,
};
use opentelemetry_proto::tonic::trace::v1::{ResourceSpans, ScopeSpans, Span, Status};
use prost::Message;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use std::fs;
use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{Duration, Instant};

static NEXT: AtomicU64 = AtomicU64::new(0);

struct Scratch(PathBuf);
impl Scratch {
    fn new() -> Self {
        let id = NEXT.fetch_add(1, Ordering::Relaxed);
        let path = std::env::temp_dir().join(format!("history-test-{}-{id}", std::process::id()));
        let _ = fs::remove_dir_all(&path);
        fs::create_dir_all(&path).unwrap();
        Self(path.canonicalize().unwrap())
    }
    fn path(&self, name: &str) -> PathBuf {
        self.0.join(name)
    }
}
impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}

fn openssl(args: &[&str], dir: &Path) {
    let out = Command::new("openssl")
        .args(args)
        .current_dir(dir)
        .output()
        .unwrap();
    assert!(
        out.status.success(),
        "{}",
        String::from_utf8_lossy(&out.stderr)
    );
}

fn make_certs(dir: &Path) {
    openssl(
        &[
            "req",
            "-x509",
            "-newkey",
            "ec",
            "-pkeyopt",
            "ec_paramgen_curve:P-256",
            "-nodes",
            "-keyout",
            "ca.key",
            "-out",
            "ca.pem",
            "-days",
            "2",
            "-subj",
            "/CN=fabric test CA",
            "-addext",
            "basicConstraints=critical,CA:TRUE",
            "-addext",
            "keyUsage=critical,keyCertSign,cRLSign",
        ],
        dir,
    );
    openssl(
        &[
            "req",
            "-newkey",
            "ec",
            "-pkeyopt",
            "ec_paramgen_curve:P-256",
            "-nodes",
            "-keyout",
            "server.key",
            "-out",
            "server.csr",
            "-subj",
            "/CN=127.0.0.1",
        ],
        dir,
    );
    fs::write(dir.join("san.ext"), "subjectAltName=IP:127.0.0.1\nbasicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=serverAuth\n").unwrap();
    openssl(
        &[
            "x509",
            "-req",
            "-in",
            "server.csr",
            "-CA",
            "ca.pem",
            "-CAkey",
            "ca.key",
            "-CAcreateserial",
            "-out",
            "server.pem",
            "-days",
            "2",
            "-extfile",
            "san.ext",
        ],
        dir,
    );
}

fn config(root: &Path, file_bytes: u64, retention_bytes: u64) -> Config {
    Config {
        listen: "127.0.0.1:0".parse().unwrap(),
        tls_cert: root.join("server.pem"),
        tls_key: root.join("server.key"),
        state_dir: root.join("server-state"),
        admin_token_file: root.join("admin-token"),
        journal_bytes: 256 * 1024 * 1024,
        journal_file_bytes: file_bytes,
        retention_s: 86400,
        retention_bytes,
        query_plan: Plan::Scan,
        seal_workers: 2,
    }
}

struct Running {
    handle: axum_server::Handle,
    thread: Option<std::thread::JoinHandle<std::io::Result<()>>>,
    addr: SocketAddr,
}
impl Running {
    fn stop(mut self) {
        self.handle.graceful_shutdown(Some(Duration::from_secs(5)));
        self.thread.take().unwrap().join().unwrap().unwrap();
    }
}

fn start(config: Config) -> Running {
    let handle = axum_server::Handle::new();
    let serving = handle.clone();
    let thread = std::thread::spawn(move || {
        tokio::runtime::Runtime::new()
            .unwrap()
            .block_on(fabric_server::serve(config, CommitMode::GROUPED, serving))
    });
    let addr = tokio::runtime::Runtime::new()
        .unwrap()
        .block_on(async {
            tokio::time::timeout(Duration::from_secs(10), handle.listening())
                .await
                .ok()
                .flatten()
        })
        .expect("server did not listen");
    Running {
        handle,
        thread: Some(thread),
        addr,
    }
}

fn admin_token() -> String {
    Sha256::digest(b"admin")
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect()
}

/// Enroll `names` before the server starts; returns token file paths.
fn enroll(scratch: &Scratch, names: &[&str]) -> Vec<PathBuf> {
    fs::write(scratch.path("admin-token"), format!("{}\n", admin_token())).unwrap();
    let mut control = Control::open(&scratch.path("server-state")).unwrap();
    names
        .iter()
        .map(|name| {
            let (_, token) = control
                .enroll(
                    name,
                    DesiredConfig {
                        logs: vec![],
                        metric_interval_s: 15,
                    },
                )
                .unwrap();
            let path = scratch.path(&format!("token-{name}"));
            fs::write(&path, format!("{token}\n")).unwrap();
            path
        })
        .collect()
}

fn kv(key: &str, value: &str) -> KeyValue {
    KeyValue {
        key: key.into(),
        value: Some(AnyValue {
            value: Some(any_value::Value::StringValue(value.into())),
        }),
        ..Default::default()
    }
}

/// A batch with `n` log lines at `t0 + i` and one monotonic counter point.
fn payload(t0: u64, n: u64, counter: i64, start: u64) -> Batch {
    let logs = ExportLogsServiceRequest {
        resource_logs: vec![ResourceLogs {
            scope_logs: vec![ScopeLogs {
                log_records: (0..n)
                    .map(|i| LogRecord {
                        observed_time_unix_nano: t0 + i,
                        body: Some(AnyValue {
                            value: Some(any_value::Value::StringValue(format!(
                                "line {t0}+{i} {}",
                                if i % 3 == 0 { "needle" } else { "hay" }
                            ))),
                        }),
                        attributes: vec![kv("log.file.path", "/var/log/app.log")],
                        ..Default::default()
                    })
                    .collect(),
                ..Default::default()
            }],
            ..Default::default()
        }],
    };
    let metrics = ExportMetricsServiceRequest {
        resource_metrics: vec![ResourceMetrics {
            scope_metrics: vec![ScopeMetrics {
                metrics: vec![Metric {
                    name: "system.network.receive.bytes".into(),
                    unit: "By".into(),
                    data: Some(metric::Data::Sum(Sum {
                        data_points: vec![NumberDataPoint {
                            attributes: vec![kv("interface", "eth0")],
                            start_time_unix_nano: start,
                            time_unix_nano: t0,
                            value: Some(number_data_point::Value::AsInt(counter)),
                            ..Default::default()
                        }],
                        aggregation_temporality: 2,
                        is_monotonic: true,
                    })),
                    ..Default::default()
                }],
                ..Default::default()
            }],
            ..Default::default()
        }],
    };
    // Three spans per batch: a root and two children, two batches per trace, kinds
    // and statuses varying, and every eleventh batch a span whose kind is outside the
    // OTLP enum (kept as its integer; a tail block cannot carry it).
    let k = (t0 - 1_000_000) / 100;
    let trace_id: Vec<u8> = (0..16).map(|i| (k / 2) as u8 ^ (i * 17)).collect();
    let span_id = |i: u64| (k * 10 + i + 1).to_be_bytes().to_vec();
    let traces = ExportTraceServiceRequest {
        resource_spans: vec![ResourceSpans {
            scope_spans: vec![ScopeSpans {
                spans: (0..3)
                    .map(|i| Span {
                        trace_id: trace_id.clone(),
                        span_id: span_id(i),
                        parent_span_id: if i == 0 { vec![] } else { span_id(0) },
                        name: if i == 0 {
                            "GET /items".into()
                        } else {
                            format!("db.query.{i}")
                        },
                        kind: if k.is_multiple_of(11) && i == 2 {
                            9
                        } else {
                            1 + i as i32
                        },
                        start_time_unix_nano: t0 + 3 * i,
                        end_time_unix_nano: t0 + 3 * i + 5,
                        attributes: vec![kv("http.route", "/items")],
                        status: (i == 1).then(|| Status {
                            code: (k % 3) as i32,
                            ..Default::default()
                        }),
                        ..Default::default()
                    })
                    .collect(),
                ..Default::default()
            }],
            ..Default::default()
        }],
    };
    Batch {
        version: 1,
        node_id: vec![],
        generation: 0,
        sequence: 0,
        metrics: metrics.encode_to_vec(),
        logs: logs.encode_to_vec(),
        traces: traces.encode_to_vec(),
        cursors: vec![],
        collection_gaps: if t0.is_multiple_of(7) {
            vec![format!("gap at {t0}")]
        } else {
            vec![]
        },
    }
}

/// Commit `count` batches to a node spool and deliver them.
fn deliver(spool: &Path, sender: &Sender, first: u64, count: u64) {
    let mut journal = Spool::open(spool, 64 * 1024 * 1024).unwrap();
    for k in first..first + count {
        let start = if k < 20 { 1_000 } else { 5_000 }; // one counter reset
        let counter = (k as i64 % 20) * 1000 + 17;
        let batch = journal
            .append(&payload(1_000_000 + k * 100, 25, counter, start))
            .unwrap();
        let answer = sender.send(&batch.encode_to_vec());
        assert!(matches!(answer, Delivery::Ack(_)), "{answer:?}");
    }
}

fn sender(root: &Path, addr: SocketAddr, token: &Path) -> Sender {
    Sender::new(&ServerTarget {
        url: format!("https://{addr}"),
        ca: root.join("ca.pem"),
        token_file: token.to_path_buf(),
    })
    .unwrap()
}

fn query(root: &Path, addr: SocketAddr, body: &Value) -> (u16, Value) {
    let agent = agent(&root.join("ca.pem")).unwrap();
    let mut response = agent
        .post(&format!("https://{addr}/v1/admin/query"))
        .header("authorization", &format!("Bearer {}", admin_token()))
        .header("content-type", "application/json")
        .send(body.to_string())
        .unwrap();
    let status = response.status().as_u16();
    let text = response
        .body_mut()
        .with_config()
        .limit(64 << 20)
        .read_to_string()
        .unwrap();
    (status, serde_json::from_str(&text).unwrap_or(Value::Null))
}

/// Every page of a query, following `next_page`.
fn all_pages(root: &Path, addr: SocketAddr, body: Value) -> Vec<Value> {
    pages_over_http(root, addr, body, usize::MAX)
}

/// The first `max` pages of a query over HTTP (every page when there are fewer).
fn pages_over_http(root: &Path, addr: SocketAddr, mut body: Value, max: usize) -> Vec<Value> {
    let mut pages = Vec::new();
    while pages.len() < max {
        let (status, page) = query(root, addr, &body);
        assert_eq!(status, 200, "{page}");
        let next = page["next_page"].clone();
        pages.push(page);
        if next.is_null() {
            return pages;
        }
        body["page"] = next;
    }
    pages
}

fn b64(bytes: &[u8]) -> String {
    const T: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::new();
    for chunk in bytes.chunks(3) {
        let n = chunk
            .iter()
            .enumerate()
            .fold(0_u32, |a, (i, b)| a | (u32::from(*b) << (16 - 8 * i)));
        for i in 0..4 {
            out.push(if i <= chunk.len() {
                T[((n >> (18 - 6 * i)) & 63) as usize] as char
            } else {
                '='
            });
        }
    }
    out
}

/// Grade pages with the independent oracle over the server's retained records.
fn oracle(
    scratch: &Scratch,
    cfg: &Config,
    query: &Value,
    pages: &[Value],
    unavailable: Option<&Value>,
) -> Value {
    let mut records = String::new();
    Store::replay(&cfg.state_dir, cfg.journal_bytes, |entry| {
        records.push_str(&json!({"label": entry.label, "received_ns": entry.received_unix_nano, "bytes": b64(&entry.batch)}).to_string());
        records.push('\n');
        Ok(())
    })
    .unwrap();
    fs::write(scratch.path("records.jsonl"), records).unwrap();
    fs::write(scratch.path("query.json"), query.to_string()).unwrap();
    fs::write(
        scratch.path("answer.json"),
        Value::Array(pages.to_vec()).to_string(),
    )
    .unwrap();
    let mut cmd = Command::new("python3");
    cmd.arg("-B")
        .arg(
            PathBuf::from(env!("CARGO_MANIFEST_DIR"))
                .join("../../tools/qualification/query_oracle.py"),
        )
        .arg("--records")
        .arg(scratch.path("records.jsonl"))
        .arg("--query")
        .arg(scratch.path("query.json"))
        .arg("--answer")
        .arg(scratch.path("answer.json"));
    if let Some(u) = unavailable {
        fs::write(scratch.path("unavailable.json"), u.to_string()).unwrap();
        cmd.arg("--unavailable")
            .arg(scratch.path("unavailable.json"));
    }
    let out = cmd.output().unwrap();
    serde_json::from_slice(&out.stdout).unwrap_or_else(|_| json!({"passed": false, "raw": String::from_utf8_lossy(&out.stdout), "err": String::from_utf8_lossy(&out.stderr)}))
}

fn wait_for_segments(state_dir: &Path, at_least: usize) {
    let deadline = Instant::now() + Duration::from_secs(30);
    while Instant::now() < deadline {
        let segments = fabric_server::segment::list(state_dir).unwrap().len();
        let sealed = fs::read_dir(state_dir.join("journal"))
            .unwrap()
            .filter(|e| {
                e.as_ref()
                    .unwrap()
                    .file_name()
                    .to_string_lossy()
                    .starts_with("sealed-")
            })
            .count();
        if segments >= at_least && sealed == 0 {
            return;
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    panic!("sealer did not produce {at_least} segments");
}

#[test]
fn sealed_history_answers_exactly_and_pages_are_stable() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-b"]);
    let cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    let b = sender(&scratch.0, server.addr, &tokens[1]);
    deliver(&scratch.path("spool-a"), &a, 0, 40);
    deliver(&scratch.path("spool-b"), &b, 0, 40);
    wait_for_segments(&cfg.state_dir, 2);
    // Some records remain in the journal tail as well.
    deliver(&scratch.path("spool-a"), &a, 40, 3);

    let queries = [
        json!({"kind": "logs", "from_ns": 1_000_000, "to_ns": 1_004_000, "limit": 37}),
        json!({"kind": "logs", "node": "node-b", "from_ns": 1_000_000, "to_ns": 1_010_000, "contains": "needle", "limit": 50}),
        json!({"kind": "metrics", "name": "system.network.receive.bytes", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 9}),
        json!({"kind": "spans", "from_ns": 1_000_000, "to_ns": 1_004_000, "limit": 23}),
        json!({"kind": "spans", "node": "node-a", "from_ns": 0, "to_ns": u64::MAX / 2, "name": "db.query.2", "limit": 7}),
        json!({"kind": "spans", "from_ns": 0, "to_ns": u64::MAX / 2, "trace_id": (0..16u8).map(|i| format!("{:02x}", 5u8 ^ i.wrapping_mul(17))).collect::<String>(), "limit": 5}),
    ];
    let mut graded = Vec::new();
    for q in &queries {
        graded.push((q.clone(), all_pages(&scratch.0, server.addr, q.clone())));
    }
    let rate = json!({"kind": "rate", "node": "node-a", "name": "system.network.receive.bytes", "from_ns": 0, "to_ns": u64::MAX / 2});
    let (status, rate_answer) = query(&scratch.0, server.addr, &rate);
    assert_eq!(status, 200);
    graded.push((rate, vec![rate_answer]));
    // A page token is bound to its query.
    let first = &graded[0].1[0];
    let mut wrong = queries[1].clone();
    wrong["page"] = first["next_page"].clone();
    assert_eq!(query(&scratch.0, server.addr, &wrong).0, 400);
    server.stop();

    for (q, pages) in &graded {
        let verdict = oracle(&scratch, &cfg, q, pages, None);
        assert_eq!(verdict["passed"], true, "query {q}: {verdict}");
    }
}

#[test]
fn crash_states_of_sealing_never_serve_a_record_twice() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a"]);
    let cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    deliver(&scratch.path("spool-a"), &a, 0, 30);
    wait_for_segments(&cfg.state_dir, 1);
    server.stop();
    let before = {
        let mut n = 0;
        Store::replay(&cfg.state_dir, cfg.journal_bytes, |_| {
            n += 1;
            Ok(())
        })
        .unwrap();
        n
    };
    assert_eq!(before, 30);
    let segments = cfg.state_dir.join("segments");
    let (label, _) = fabric_server::segment::list(&cfg.state_dir).unwrap()[0].clone();
    // State A: killed while building: a leftover .building directory.
    fs::create_dir_all(segments.join(".building-00000000000000000099")).unwrap();
    fs::write(
        segments.join(".building-00000000000000000099/logs.parquet"),
        b"partial",
    )
    .unwrap();
    // State B: segment committed, journal file not yet reclaimed. Rebuild the
    // sealed file from the segment's own records to reproduce that state.
    let dir = segments.join(fabric_server::segment::segment_name(label));
    let manifest = fabric_server::segment::read_manifest(&dir).unwrap();
    let mut groups: std::collections::BTreeMap<u64, Vec<fabric_server::store::Entry>> =
        Default::default();
    fabric_server::segment::scan_batches(&dir, &manifest, |g, e| {
        groups.entry(g).or_default().push(e)
    })
    .unwrap();
    let journal = cfg.state_dir.join("journal");
    fs::create_dir_all(scratch.path("rebuild")).unwrap();
    let mut log =
        fabric_frame::frame::FrameLog::open(&scratch.path("rebuild"), 1 << 30, 4 << 20, |_, _| {
            Ok(())
        })
        .unwrap();
    for (g, entries) in &groups {
        log.append(
            &fabric_server::store::Group {
                group_sequence: *g,
                entries: entries.clone(),
            }
            .encode_to_vec(),
        )
        .unwrap();
    }
    drop(log);
    fs::copy(
        scratch.path("rebuild/batches.faj"),
        journal.join(format!("sealed-{label:020}.faj")),
    )
    .unwrap();
    // A query in the live window between segment commit and reclaim sees
    // each record once, although both copies exist.
    let history = fabric_server::query::History::new(&cfg.state_dir);
    let all = serde_json::from_value(
        json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 10000}),
    )
    .unwrap();
    let live = history
        .run(&all, *groups.keys().max().unwrap() + 1000)
        .unwrap();
    assert_eq!(live["rows"].as_array().unwrap().len(), 30 * 25);
    let walk = History::with_plan(&cfg.state_dir, Plan::Walk);
    let walked = walk
        .run(&all, *groups.keys().max().unwrap() + 1000)
        .unwrap();
    assert_eq!(
        walked, live,
        "the walk plan must answer the live window as the scan does"
    );
    // Restart: the leftover build is removed and the duplicate journal file
    // is reclaimed before serving.
    let server = start(cfg.clone());
    let (status, answer) = query(
        &scratch.0,
        server.addr,
        &json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 10000}),
    );
    assert_eq!(status, 200);
    assert_eq!(answer["rows"].as_array().unwrap().len(), 30 * 25);
    assert!(!segments.join(".building-00000000000000000099").exists());
    assert!(!journal.join(format!("sealed-{label:020}.faj")).exists());
    server.stop();
}

#[test]
fn retention_removes_old_segments_and_stream_state_survives_it() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a"]);
    // Keep about one segment.
    let cfg = config(&scratch.0, 16 * 1024, 20 * 1024);
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    deliver(&scratch.path("spool-a"), &a, 0, 25);
    let first_page = query(
        &scratch.0,
        server.addr,
        &json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 5}),
    )
    .1;
    deliver(&scratch.path("spool-a"), &a, 25, 60);
    wait_for_segments(&cfg.state_dir, 1);
    std::thread::sleep(Duration::from_secs(3)); // at least one retention pass
    let segments = fabric_server::segment::list(&cfg.state_dir).unwrap();
    let total: u64 = segments
        .iter()
        .map(|(_, m)| m.files.values().map(|f| f.bytes).sum::<u64>())
        .sum();
    assert!(total <= 20 * 1024, "retention left {total} bytes");
    assert!(
        segments.first().unwrap().1.first_group > 1,
        "oldest segment was not deleted"
    );
    // A page bound to deleted history is Gone.
    let mut next = json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 5});
    next["page"] = first_page["next_page"].clone();
    assert_eq!(query(&scratch.0, server.addr, &next).0, 410);
    let (_, fresh) = query(
        &scratch.0,
        server.addr,
        &json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 1}),
    );
    assert!(
        fresh["retained_from_ns"].as_u64().unwrap()
            > first_page["retained_from_ns"].as_u64().unwrap()
    );
    server.stop();
    // Every early batch left the journal; a restarted server still knows the
    // stream and acknowledges the next sequence instead of reporting a gap.
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    deliver(&scratch.path("spool-a"), &a, 85, 1);
    server.stop();
}

#[test]
fn a_corrupt_segment_makes_the_answer_incomplete() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a"]);
    let cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    deliver(&scratch.path("spool-a"), &a, 0, 30);
    wait_for_segments(&cfg.state_dir, 1);
    let (label, _) = fabric_server::segment::list(&cfg.state_dir).unwrap()[0].clone();
    let logs = cfg
        .state_dir
        .join("segments")
        .join(fabric_server::segment::segment_name(label))
        .join("logs.parquet");
    let mut bytes = fs::read(&logs).unwrap();
    let middle = bytes.len() / 2;
    bytes.truncate(middle);
    fs::write(&logs, bytes).unwrap();
    let (status, answer) = query(
        &scratch.0,
        server.addr,
        &json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 10000}),
    );
    assert_eq!(status, 200);
    assert_eq!(answer["complete"], false);
    assert_eq!(answer["unavailable"].as_array().unwrap().len(), 1);
    server.stop();
    let all: Query = serde_json::from_value(
        json!({"kind": "logs", "from_ns": 0, "to_ns": u64::MAX / 2, "limit": 10000}),
    )
    .unwrap();
    let walked = History::with_plan(&cfg.state_dir, Plan::Walk)
        .run(&all, 1 << 40)
        .unwrap();
    assert_eq!(
        walked["complete"], false,
        "the walk plan must report the corrupt Segment"
    );
    assert_eq!(walked["unavailable"].as_array().unwrap().len(), 1);
    assert_eq!(
        walked,
        History::new(&cfg.state_dir).run(&all, 1 << 40).unwrap()
    );
}

/// What a query answer means, without the parts that legitimately differ
/// between two snapshots of the same history: page tokens, the snapshot
/// name, the newest receive time, and the freshness of `exclude`.
fn meaning(pages: &[Value], exclude: &str) -> Value {
    let rows: Vec<Value> = pages
        .iter()
        .flat_map(|p| p["rows"].as_array().cloned().unwrap_or_default())
        .collect();
    let mut freshness = pages[0]["freshness"].clone();
    if let Some(map) = freshness.as_object_mut() {
        map.remove(exclude);
    }
    json!({
        "rows": rows,
        "complete": pages.iter().all(|p| p["complete"] == true),
        "unavailable": pages.iter().map(|p| p["unavailable"].clone()).collect::<Vec<_>>(),
        "gaps": pages.iter().map(|p| p["gaps"].clone()).collect::<Vec<_>>(),
        "freshness": freshness,
        "retained_from_ns": pages[0]["retained_from_ns"],
    })
}

/// Metamorphic relations HIST-1 and HIST-2 (verification strategy): the same
/// committed history answers the same whether it is read from the journal
/// alone or from a sealed Segment, and sealing does not change an answer.
/// The first server never seals; after a restart with a small journal file
/// size, one extra Batch from another Spindle, outside every queried range,
/// rotates the journal and the sealer turns the old file into a Segment.
#[test]
fn journal_and_segment_representations_answer_identically() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-b", "node-c"]);
    let unsealed = config(&scratch.0, 1 << 30, 1 << 30);
    let server = start(unsealed.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    let b = sender(&scratch.0, server.addr, &tokens[1]);
    deliver(&scratch.path("spool-a"), &a, 0, 30);
    deliver(&scratch.path("spool-b"), &b, 0, 30);
    let queries = [
        json!({"kind": "logs", "from_ns": 1_000_000, "to_ns": 1_050_000, "limit": 97}),
        json!({"kind": "logs", "node": "node-b", "from_ns": 1_000_000, "to_ns": 1_050_000, "contains": "needle", "limit": 41}),
        json!({"kind": "metrics", "name": "system.network.receive.bytes", "from_ns": 0, "to_ns": 1_050_000, "limit": 7}),
        json!({"kind": "rate", "name": "system.network.receive.bytes", "from_ns": 0, "to_ns": 1_050_000}),
    ];
    let journal_only: Vec<Value> = queries
        .iter()
        .map(|q| meaning(&all_pages(&scratch.0, server.addr, q.clone()), "node-c"))
        .collect();
    assert_eq!(
        fabric_server::segment::list(&unsealed.state_dir)
            .unwrap()
            .len(),
        0,
        "the first server must answer from the journal alone"
    );
    server.stop();

    let sealing = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(sealing.clone());
    let c = sender(&scratch.0, server.addr, &tokens[2]);
    deliver(&scratch.path("spool-c"), &c, 1000, 1);
    wait_for_segments(&sealing.state_dir, 1);
    let from_segments: Vec<Value> = queries
        .iter()
        .map(|q| meaning(&all_pages(&scratch.0, server.addr, q.clone()), "node-c"))
        .collect();
    server.stop();

    for ((q, before), after) in queries.iter().zip(&journal_only).zip(&from_segments) {
        assert!(
            !before["rows"].as_array().unwrap().is_empty(),
            "query {q} must return rows"
        );
        assert_eq!(before["complete"], true, "query {q}");
        assert_eq!(
            before, after,
            "query {q} changed when its history was sealed"
        );
    }
}

/// The first `max` pages of a query answered in process by `history` at snapshot
/// `newest` (every page when there are fewer).
fn pages_in_process(history: &History, mut body: Value, newest: u64) -> Vec<Value> {
    pages_upto(history, &mut body, newest, 60)
}

fn pages_upto(history: &History, body: &mut Value, newest: u64, max: usize) -> Vec<Value> {
    let mut pages = Vec::new();
    for _ in 0..max {
        let query: Query = serde_json::from_value(body.clone()).unwrap();
        let page = history.run(&query, newest).expect("query failed");
        let next = page["next_page"].clone();
        pages.push(page);
        if next.is_null() {
            return pages;
        }
        body["page"] = next;
    }
    pages
}

/// Seeded queries over the delivered range: every kind, windows from empty to
/// everything, limits from 1 to 1,000, nodes present and absent, text present,
/// absent and spanning a word boundary.
fn seeded_queries(n: usize, seed: u64) -> Vec<Value> {
    let mut state = seed;
    let mut next = move |m: u64| {
        state = state
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        (state >> 33) % m
    };
    let nodes = [None, None, Some("node-a"), Some("node-b"), Some("node-z")];
    let texts = [
        None,
        None,
        Some("needle"),
        Some("hay"),
        Some("zq9"),
        Some("+1 hay"),
    ];
    let limits = [1, 3, 10, 37, 1000];
    (0..n)
        .map(|_| {
            let from = 999_000 + next(6_000);
            let to = from + 1 + [next(50), next(500), next(5_000), 1 << 40][next(4) as usize];
            let mut q = match next(5) {
                4 => {
                    let mut q = json!({"kind": "spans", "from_ns": from, "to_ns": to, "limit": limits[next(5) as usize]});
                    match next(3) {
                        0 => {
                            let k = next(44);
                            let id: String = (0..16).map(|i| format!("{:02x}", (k / 2) as u8 ^ (i * 17))).collect();
                            q["trace_id"] = json!(id);
                        }
                        1 => q["name"] = json!(["GET /items", "db.query.1", "nope"][next(3) as usize]),
                        _ => {}
                    }
                    q
                }
                0 | 1 => json!({"kind": "logs", "from_ns": from, "to_ns": to, "limit": limits[next(5) as usize]}),
                2 => json!({"kind": "metrics", "name": "system.network.receive.bytes", "from_ns": from, "to_ns": to, "limit": limits[next(5) as usize]}),
                _ => json!({"kind": "rate", "name": "system.network.receive.bytes", "from_ns": from, "to_ns": to}),
            };
            if let Some(node) = nodes[next(5) as usize] {
                q["node"] = json!(node);
            }
            if q["kind"] == "logs"
                && let Some(text) = texts[next(6) as usize]
            {
                q["contains"] = json!(text);
            }
            q
        })
        .collect()
}

/// ADR-0024, part 1: the walk plan returns, page for page, the scan plan's answer.
/// Three Spindles write lines at identical times, so every source overlaps another
/// and ties on time are broken by node, sequence and index; part of the history is
/// sealed into Segments and part stays in the journal tail. The walk's own answers
/// are also graded by the independent oracle.
#[test]
fn walk_and_scan_plans_answer_identically() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-b", "node-c"]);
    let cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    let b = sender(&scratch.0, server.addr, &tokens[1]);
    let c = sender(&scratch.0, server.addr, &tokens[2]);
    deliver(&scratch.path("spool-a"), &a, 0, 40);
    deliver(&scratch.path("spool-b"), &b, 0, 40);
    deliver(&scratch.path("spool-c"), &c, 0, 40);
    wait_for_segments(&cfg.state_dir, 2);
    deliver(&scratch.path("spool-a"), &a, 40, 4);
    deliver(&scratch.path("spool-b"), &b, 40, 2);
    server.stop();
    assert!(fabric_server::segment::list(&cfg.state_dir).unwrap().len() >= 2);

    let scan = History::new(&cfg.state_dir);
    let walk = History::with_plan(&cfg.state_dir, Plan::Walk);
    let mut queries = seeded_queries(150, 7);
    // Three Spindles write at the same instants, so a heap of one or two rows fills
    // with keys whose time equals the next source's lowest bound: the case in which a
    // stop at `bound >= threshold` instead of `bound > threshold` drops a row.
    for k in (0..44).step_by(5) {
        let from = 1_000_000 + k * 100;
        for limit in [1, 2] {
            queries.push(
                json!({"kind": "logs", "from_ns": from, "to_ns": from + 1000, "limit": limit}),
            );
            queries.push(json!({"kind": "metrics", "name": "system.network.receive.bytes", "from_ns": from, "to_ns": 1u64 << 40, "limit": limit}));
        }
    }
    let mut rows = 0;
    for q in &queries {
        let expected = pages_in_process(&scan, q.clone(), 1 << 40);
        let got = pages_in_process(&walk, q.clone(), 1 << 40);
        assert_eq!(got, expected, "query {q}");
        rows += expected
            .iter()
            .map(|p| p["rows"].as_array().map_or(0, |r| r.len()))
            .sum::<usize>();
    }
    assert!(rows > 2_000, "the seeded queries must return rows ({rows})");
    // One whole history drained in pages of 97, every page compared.
    let drain = json!({"kind": "logs", "from_ns": 0, "to_ns": 1u64 << 40, "limit": 97});
    let expected = pages_upto(&scan, &mut drain.clone(), 1 << 40, 10_000);
    assert!(expected.last().unwrap()["next_page"].is_null() && expected.len() > 20);
    assert_eq!(
        pages_upto(&walk, &mut drain.clone(), 1 << 40, 10_000),
        expected
    );
    for q in queries.iter().filter(|q| q["kind"] != "rate").take(12) {
        let pages = pages_upto(&walk, &mut q.clone(), 1 << 40, 10_000);
        let verdict = oracle(&scratch, &cfg, q, &pages, None);
        assert_eq!(verdict["passed"], true, "query {q}: {verdict}");
    }
}

/// The walk plan in a running server: its tail index grows between queries and
/// loses entries to sealing, and its answers stay those of the scan plan.
#[test]
fn a_walking_server_keeps_its_tail_index_exact_while_sealing() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-b"]);
    let mut cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    cfg.query_plan = Plan::Walk;
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    let b = sender(&scratch.0, server.addr, &tokens[1]);
    let probe = json!({"kind": "logs", "from_ns": 0, "to_ns": 1u64 << 40, "limit": 1000});
    for round in 0..5 {
        deliver(&scratch.path("spool-a"), &a, round * 8, 8);
        deliver(&scratch.path("spool-b"), &b, round * 8, 8);
        let pages = all_pages(&scratch.0, server.addr, probe.clone());
        let total: usize = pages
            .iter()
            .map(|p| p["rows"].as_array().unwrap().len())
            .sum();
        assert_eq!(total as u64, 2 * (round + 1) * 8 * 25, "round {round}");
    }
    wait_for_segments(&cfg.state_dir, 2);
    let queries = seeded_queries(60, 11);
    let answers: Vec<Vec<Value>> = queries
        .iter()
        .map(|q| pages_over_http(&scratch.0, server.addr, q.clone(), 60))
        .collect();
    server.stop();
    let scan = History::new(&cfg.state_dir);
    for (q, pages) in queries.iter().zip(&answers) {
        let snapshot = pages[0]["snapshot"].as_str().unwrap();
        let newest: u64 = snapshot.rsplit('-').next().unwrap().parse().unwrap();
        assert_eq!(
            &pages_in_process(&scan, q.clone(), newest),
            pages,
            "query {q}"
        );
    }
}

/// ADR-0024 part 2: every Segment carries a verified trigram filter per logs row
/// group. A filter whose bytes no longer match the manifest is ignored and the walk
/// scans exactly (the contract's rule for optional indexes); a filter that lies with
/// a matching digest (a faulty sealer, the filter's trust assumption) makes the walk
/// drop rows, and the equivalence check catches it.
#[test]
fn text_filters_skip_only_groups_without_the_needle_and_fall_back_when_corrupt() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-b"]);
    let cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(cfg.clone());
    let a = sender(&scratch.0, server.addr, &tokens[0]);
    let b = sender(&scratch.0, server.addr, &tokens[1]);
    deliver(&scratch.path("spool-a"), &a, 0, 40);
    deliver(&scratch.path("spool-b"), &b, 0, 40);
    wait_for_segments(&cfg.state_dir, 2);
    server.stop();

    let segments_dir = cfg.state_dir.join("segments");
    let segments = fabric_server::segment::list(&cfg.state_dir).unwrap();
    for (label, manifest) in &segments {
        let dir = segments_dir.join(fabric_server::segment::segment_name(*label));
        let filters =
            fabric_server::segment::read_text_filter(&dir, manifest).expect("a verified filter");
        let groups = fabric_server::segment::row_group_bounds(
            &dir,
            manifest,
            fabric_server::segment::Table::Logs,
        )
        .unwrap();
        assert_eq!(filters.len(), groups.len());
        assert!(
            filters
                .iter()
                .all(|g| g.may_contain(b"needle") && !g.may_contain(b"zq9"))
        );
    }

    let queries: Vec<Value> = ["needle", "hay", "zq9", "+1 hay", "line 1000"]
        .iter()
        .flat_map(|t| {
            [5, 1000].map(|limit| json!({"kind": "logs", "from_ns": 0, "to_ns": 1u64 << 40, "contains": t, "limit": limit}))
        })
        .collect();
    let scan = History::new(&cfg.state_dir);
    let expected: Vec<Vec<Value>> = queries
        .iter()
        .map(|q| pages_in_process(&scan, q.clone(), 1 << 40))
        .collect();
    let same = |history: &History| {
        queries
            .iter()
            .zip(&expected)
            .all(|(q, e)| &pages_in_process(history, q.clone(), 1 << 40) == e)
    };
    assert!(
        same(&History::with_plan(&cfg.state_dir, Plan::Walk)),
        "the filtered walk must answer as the scan"
    );

    // Zero every filter's bits on disk: the digest no longer matches, the filters
    // are ignored, the answers stay exact.
    let (label, manifest) = segments[0].clone();
    let dir = segments_dir.join(fabric_server::segment::segment_name(label));
    let path = dir.join(fabric_server::text_filter::FILE);
    let original = fs::read(&path).unwrap();
    let groups = fabric_server::text_filter::decode(&original).unwrap().len();
    let mut zeroed = original.clone();
    let header = 8 + 4 * groups;
    zeroed[header..].fill(0);
    fs::write(&path, &zeroed).unwrap();
    assert!(fabric_server::segment::read_text_filter(&dir, &manifest).is_none());
    assert!(
        same(&History::with_plan(&cfg.state_dir, Plan::Walk)),
        "a corrupt filter must fall back to the exact scan"
    );

    // Negative control: the same lying filter with its digest written into the
    // manifest is believed, rows of that Segment are dropped, and the check sees it.
    let mut lying = manifest.clone();
    let entry = lying
        .files
        .get_mut(fabric_server::text_filter::FILE)
        .unwrap();
    entry.sha256 = Sha256::digest(&zeroed)
        .iter()
        .map(|b| format!("{b:02x}"))
        .collect();
    fs::write(
        dir.join("manifest.json"),
        serde_json::to_vec_pretty(&lying).unwrap(),
    )
    .unwrap();
    assert!(fabric_server::segment::read_text_filter(&dir, &lying).is_some());
    assert!(
        !same(&History::with_plan(&cfg.state_dir, Plan::Walk)),
        "a lying filter must be visible to the equivalence check"
    );
}

/// ADR-0024 part 3: the walk reads complete tail blocks (FOB1, derived from the
/// journal in memory) in place of decoding entries, and answers as the scan does.
/// Blocks here close at 60 records so a small tail has many; three Spindles write at
/// the same instants, part of the history is sealed and most stays in the tail.
#[test]
fn a_block_tail_answers_as_the_scan_does() {
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-b", "node-c"]);
    let cfg = config(&scratch.0, 16 * 1024, 1 << 30);
    let server = start(cfg.clone());
    let senders: Vec<_> = tokens
        .iter()
        .map(|t| sender(&scratch.0, server.addr, t))
        .collect();
    for (i, s) in senders.iter().enumerate() {
        deliver(&scratch.path(&format!("spool-{i}")), s, 0, 20);
    }
    wait_for_segments(&cfg.state_dir, 1);
    server.stop();
    // A larger journal file keeps the rest unsealed.
    let unsealed = config(&scratch.0, 1 << 30, 1 << 30);
    let server = start(unsealed.clone());
    let senders: Vec<_> = tokens
        .iter()
        .map(|t| sender(&scratch.0, server.addr, t))
        .collect();
    for (i, s) in senders.iter().enumerate() {
        deliver(&scratch.path(&format!("spool-{i}")), s, 20, 24);
    }
    server.stop();

    let scan = History::new(&cfg.state_dir);
    let walk = History::with_plan(&cfg.state_dir, Plan::Walk).with_tail_block_records(60);
    let mut queries = seeded_queries(120, 23);
    for k in (20..44).step_by(4) {
        let from = 1_000_000 + k * 100;
        for limit in [1, 2, 7] {
            queries.push(
                json!({"kind": "logs", "from_ns": from, "to_ns": from + 1000, "limit": limit}),
            );
            queries.push(json!({"kind": "logs", "from_ns": from, "to_ns": 1u64 << 40, "contains": "needle", "limit": limit}));
            queries.push(json!({"kind": "metrics", "name": "system.network.receive.bytes", "from_ns": from, "to_ns": 1u64 << 40, "limit": limit}));
        }
        queries.push(json!({"kind": "rate", "name": "system.network.receive.bytes", "from_ns": from, "to_ns": 1u64 << 40}));
    }
    for q in &queries {
        assert_eq!(
            pages_in_process(&walk, q.clone(), 1 << 40),
            pages_in_process(&scan, q.clone(), 1 << 40),
            "query {q}"
        );
    }
    assert!(
        walk.tail_blocks() > 10,
        "the tail must be read through blocks ({})",
        walk.tail_blocks()
    );
    let drain = json!({"kind": "logs", "from_ns": 0, "to_ns": 1u64 << 40, "limit": 97});
    assert_eq!(
        pages_upto(&walk, &mut drain.clone(), 1 << 40, 10_000),
        pages_upto(&scan, &mut drain.clone(), 1 << 40, 10_000)
    );
}

/// CX-RATE-IDENTITY / CX-RATE-I53: retained function-level audit failures,
/// extended through OTLP, durable delivery, HTTP, both plans and sealing/restart.
/// The unchanged Python oracle supplies expected rows, including mixed numbers.
#[test]
fn rate_counterexamples_survive_delivery_sealing_and_restart() {
    use number_data_point::Value::{AsDouble, AsInt};
    let scratch = Scratch::new();
    make_certs(&scratch.0);
    let tokens = enroll(&scratch, &["node-a", "node-padding"]);
    let mut points = Vec::new();
    let mut add = |attributes: Vec<KeyValue>, values: Vec<number_data_point::Value>| {
        for (index, value) in values.into_iter().enumerate() {
            points.push(NumberDataPoint {
                attributes: attributes.clone(),
                start_time_unix_nano: 1,
                time_unix_nano: (index as u64 + 1) * 1_000_000_000,
                value: Some(value),
                ..Default::default()
            });
        }
    };
    // Neither singleton may invent a cross-series rate.
    add(vec![kv("a=b", "c")], vec![AsInt(10)]);
    add(vec![kv("a", "b=c")], vec![AsInt(20)]);
    // Two multi-point maps with the same old display key must stay independent.
    add(vec![kv("x=y", "z")], vec![AsInt(10), AsInt(11)]);
    add(vec![kv("x", "y=z")], vec![AsInt(100), AsInt(120)]);
    add(
        vec![kv("case", "integer")],
        vec![AsInt(1 << 53), AsInt((1 << 53) + 1), AsInt(1 << 53)],
    );
    add(
        vec![kv("case", "extremes")],
        vec![AsInt(i64::MIN), AsInt(i64::MAX), AsInt(i64::MIN)],
    );
    add(
        vec![kv("case", "mixed-decrease")],
        vec![AsInt((1 << 53) + 1), AsDouble((1u64 << 53) as f64)],
    );
    add(
        vec![kv("case", "mixed-increase")],
        vec![
            AsDouble((1u64 << 53) as f64),
            AsInt((1 << 53) + 1),
            AsDouble((1u64 << 53) as f64 + 2.0),
        ],
    );
    add(
        vec![kv("case", "mixed-fraction")],
        vec![AsInt(-2), AsDouble(-1.5), AsInt(-1), AsDouble(-1.25)],
    );
    // Many two-point series, deliberately distinct despite a common prefix.
    for series in 0..2048 {
        add(
            vec![kv("series", &format!("{series:04}"))],
            vec![AsInt((1 << 53) + series), AsInt((1 << 53) + series + 1)],
        );
    }
    let q = json!({"kind":"rate", "node":"node-a", "name":"precision.counter", "from_ns":0, "to_ns":10_000_000_000u64});
    let mut cfg = config(&scratch.0, 1 << 28, 1 << 30);
    let server = start(cfg.clone());
    let send = sender(&scratch.0, server.addr, &tokens[0]);
    let mut spool = Spool::open(scratch.path("spool-a"), 64 << 20).unwrap();
    for chunk in points.chunks(512) {
        let request = ExportMetricsServiceRequest {
            resource_metrics: vec![ResourceMetrics {
                scope_metrics: vec![ScopeMetrics {
                    metrics: vec![Metric {
                        name: "precision.counter".into(),
                        data: Some(metric::Data::Sum(Sum {
                            data_points: chunk.to_vec(),
                            aggregation_temporality: 2,
                            is_monotonic: true,
                        })),
                        ..Default::default()
                    }],
                    ..Default::default()
                }],
                ..Default::default()
            }],
        };
        let batch = spool
            .append(&Batch {
                version: 1,
                metrics: request.encode_to_vec(),
                ..Default::default()
            })
            .unwrap();
        assert!(matches!(
            send.send(&batch.encode_to_vec()),
            Delivery::Ack(_)
        ));
    }
    let (status, tail) = query(&scratch.0, server.addr, &q);
    assert_eq!(status, 200);
    assert_eq!(tail["rows"].as_array().unwrap().len(), 2060);
    server.stop();
    let verdict = oracle(&scratch, &cfg, &q, std::slice::from_ref(&tail), None);
    assert_eq!(verdict["passed"], true, "{verdict}");
    // Reopened walk answers the journal, then small rotation seals these Batches.
    cfg.query_plan = Plan::Walk;
    let server = start(cfg.clone());
    assert_eq!(query(&scratch.0, server.addr, &q).1["rows"], tail["rows"]);
    server.stop();
    cfg.journal_file_bytes = 16 * 1024;
    let server = start(cfg.clone());
    let padding = sender(&scratch.0, server.addr, &tokens[1]);
    deliver(&scratch.path("spool-padding"), &padding, 1000, 1);
    wait_for_segments(&cfg.state_dir, 1);
    let sealed = query(&scratch.0, server.addr, &q).1;
    assert_eq!(sealed["rows"], tail["rows"]);
    server.stop();
    for plan in [Plan::Scan, Plan::Walk] {
        cfg.query_plan = plan;
        let server = start(cfg.clone());
        let (status, answer) = query(&scratch.0, server.addr, &q);
        assert_eq!(status, 200);
        assert_eq!(answer["rows"], tail["rows"]);
        server.stop();
        let verdict = oracle(&scratch, &cfg, &q, &[answer], None);
        assert_eq!(verdict["passed"], true, "{verdict}");
    }
}
