//! Calibration points for the cost model: bytes and nanoseconds per record as
//! a function of body length, attribute count, block size and record kind.
use fabric_observation::*;
use std::time::Instant;

fn rec(i: u64, kind: u8, body_len: usize, attrs: usize, distinct_attr_values: u64, jitter_ns: u64) -> Observation {
    let strand = Strand { node_id: [7; 16], generation: 3 };
    let mut attributes = Vec::new();
    for a in 0..attrs {
        attributes.push((format!("attr.key.{a}"), Value::Str(format!("value-{}", (i * 7 + a as u64) % distinct_attr_values))));
    }
    let time_ns = 1_800_000_000_000_000_000 + i * 500_000_000 + (i * 2_654_435_761 % (2 * jitter_ns + 1));
    let signal = match kind {
        0 => Signal::Log { severity: 9, event: String::new(), body: "x".repeat(body_len) },
        1 => Signal::Point { name: format!("sim.metric.{}", i % 32), unit: "1".into(), kind: PointKind::Gauge, value: Number::Int((i * 2_654_435_761) as i64 >> 1) },
        _ => Signal::Span { name: format!("op.{}", i % 8), end_ns: time_ns + 1_234_567, status: Status::Ok, kind: SpanKind::Server },
    };
    Observation { strand, sequence: 100 + i / 10, index: (i % 10) as u32, time_ns, locators: if kind == 2 { Some(Locators { trace_id: [1; 16], span_id: [2; 8], parent_span_id: None }) } else { None }, attributes, signal }
}

fn main() {
    println!("kind,n,body_len,attrs,distinct_values,jitter_ns,bytes_per_record,encode_ns_per_record,decode_ns_per_record,view_ns_per_record");
    let cases: Vec<(u8, usize, usize, usize, u64, u64)> = {
        let mut v = Vec::new();
        for &n in &[1usize, 16, 256, 4096, 65536] {
            for &body in &[0usize, 64, 256, 1024] { v.push((0, n, body, 0, 1, 0)); }
            for &attrs in &[0usize, 2, 5, 10] { v.push((0, n, 64, attrs, 1, 0)); }
            for &dv in &[1u64, 16, 1024, 1 << 40] { v.push((0, n, 64, 3, dv, 0)); }
            for &j in &[0u64, 1_000, 1_000_000, 1_000_000_000] { v.push((0, n, 64, 0, 1, j)); }
            v.push((1, n, 0, 1, 4, 0));
            v.push((2, n, 0, 3, 16, 0));
        }
        v
    };
    for (kind, n, body, attrs, dv, j) in cases {
        let block: Vec<Observation> = (0..n as u64).map(|i| rec(i, kind, body, attrs, dv, j)).collect();
        let reps = (2_000_000 / n.max(1)).clamp(3, 20_000);
        let mut bytes = Vec::new();
        let t = Instant::now();
        for _ in 0..reps { bytes = encode(&block).unwrap(); }
        let enc = t.elapsed().as_nanos() as f64 / (reps * n) as f64;
        let t = Instant::now();
        let mut back = Vec::new();
        for _ in 0..reps { back = decode(&bytes).unwrap(); }
        let dec = t.elapsed().as_nanos() as f64 / (reps * n) as f64;
        assert_eq!(back, block);
        let t = Instant::now();
        let mut seen = 0usize;
        for _ in 0..reps { let v = decode_view(&bytes).unwrap(); seen += v.len(); }
        let view = t.elapsed().as_nanos() as f64 / (reps * n) as f64;
        assert_eq!(seen, reps * n);
        println!("{kind},{n},{body},{attrs},{dv},{j},{:.2},{enc:.0},{dec:.0},{view:.0}", bytes.len() as f64 / n as f64);
    }
}
